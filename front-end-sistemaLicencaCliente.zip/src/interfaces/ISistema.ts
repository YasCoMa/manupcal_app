export default interface ISistema {
    id: number;
    nome: string;
    modulos: any;
    status: boolean;
    permissoes: any;
}